#!/bin/bash

set -euo pipefail

#############################################
# Load Environment
#############################################

if [ ! -f .env ]; then
    echo ".env file not found"
    exit 1
fi

set -a
source .env
set +a

#############################################
# Validate
#############################################

for var in SOURCE_ORG TARGET_ORG GH_SOURCE_PAT GH_TARGET_PAT
do
    if [ -z "${!var:-}" ]; then
        echo "$var is required"
        exit 1
    fi
done

SOURCE_HOST=${SOURCE_HOST:-github.com}
TARGET_HOST=${TARGET_HOST:-github.com}
GH_USER=${GH_USER:-$(gh api user -q .login)}
MAX_VERSIONS_PER_PACKAGE=${MAX_VERSIONS_PER_PACKAGE:-10}

if ! [[ "$MAX_VERSIONS_PER_PACKAGE" =~ ^[0-9]+$ ]]; then
    echo "MAX_VERSIONS_PER_PACKAGE must be a non-negative integer"
    exit 1
fi

#############################################
# Token Management
#############################################

# Parse comma-separated tokens into arrays
IFS=',' read -ra SOURCE_TOKENS <<< "$GH_SOURCE_PAT"
IFS=',' read -ra TARGET_TOKENS <<< "$GH_TARGET_PAT"

SOURCE_TOKEN_INDEX=0
TARGET_TOKEN_INDEX=0

get_source_token() {
    echo "${SOURCE_TOKENS[$SOURCE_TOKEN_INDEX]}" | xargs
}

get_target_token() {
    echo "${TARGET_TOKENS[$TARGET_TOKEN_INDEX]}" | xargs
}

rotate_source_token() {
    SOURCE_TOKEN_INDEX=$(( (SOURCE_TOKEN_INDEX + 1) % ${#SOURCE_TOKENS[@]} ))
    echo "Rotated to source token $((SOURCE_TOKEN_INDEX + 1))/${#SOURCE_TOKENS[@]}"
}

rotate_target_token() {
    TARGET_TOKEN_INDEX=$(( (TARGET_TOKEN_INDEX + 1) % ${#TARGET_TOKENS[@]} ))
    echo "Rotated to target token $((TARGET_TOKEN_INDEX + 1))/${#TARGET_TOKENS[@]}"
}

is_retryable_gh_error() {
    local response=$1
    echo "$response" | grep -qi "rate limit\|429\|secondary rate\|timeout\|timed out\|502\|503\|504\|connection reset"
}

gh_api_paginated_with_retry() {
    local token_type=$1
    local endpoint=$2
    local max_retries=${3:-5}
    local retry_count=0

    while [ $retry_count -lt $max_retries ]; do
        local token
        if [ "$token_type" = "source" ]; then
            token=$(get_source_token)
        else
            token=$(get_target_token)
        fi

        local response
        response=$(GH_TOKEN="$token" gh api --paginate "$endpoint" 2>&1)
        local exit_code=$?

        if [ $exit_code -eq 0 ]; then
            echo "$response"
            return 0
        fi

        if is_retryable_gh_error "$response"; then
            echo "Retryable GitHub API error for $endpoint. Rotating $token_type token and retrying..." >&2
            if [ "$token_type" = "source" ]; then
                rotate_source_token
            else
                rotate_target_token
            fi
            retry_count=$((retry_count + 1))
            sleep 2
            continue
        fi

        echo "$response" >&2
        return $exit_code
    done

    echo "Failed GitHub API call after $max_retries retries: $endpoint" >&2
    return 1
}

# Retry with token rotation on rate limit
retry_with_token_rotation() {
    local token_type=$1
    local max_retries=$2
    shift 2
    local command=("$@")
    
    local retry_count=0
    
    while [ $retry_count -lt $max_retries ]; do
        local response
        response=$("${command[@]}" 2>&1)
        local exit_code=$?
        
        if [ $exit_code -eq 0 ]; then
            echo "$response"
            return 0
        fi
        
        # Check for rate limit error
        if echo "$response" | grep -qi "rate limit\|429"; then
            echo "Rate limit detected. Rotating token..." >&2
            if [ "$token_type" = "source" ]; then
                rotate_source_token
            else
                rotate_target_token
            fi
            retry_count=$((retry_count + 1))
            sleep 2
        else
            echo "$response"
            return $exit_code
        fi
    done
    
    echo "Failed after $max_retries token rotations" >&2
    return 1
}

# Download file with token rotation and rate limit handling
download_file_with_retry() {
    local token_type=$1
    local url=$2
    local output_file=$3
    local max_retries=3
    local retry_count=0
    
    while [ $retry_count -lt $max_retries ]; do
        local token
        if [ "$token_type" = "source" ]; then
            token=$(get_source_token)
        else
            token=$(get_target_token)
        fi
        
        local response_code
        response_code=$(curl -sL -w "\n%{http_code}" \
            -u "${GH_USER}:${token}" \
            "$url" \
            -o "$output_file" | tail -n1)
        
        if [ "$response_code" = "200" ]; then
            return 0
        elif [ "$response_code" = "429" ]; then
            echo "Rate limit detected (HTTP 429). Rotating token..." >&2
            if [ "$token_type" = "source" ]; then
                rotate_source_token
            else
                rotate_target_token
            fi
            retry_count=$((retry_count + 1))
            sleep 2
        else
            echo "HTTP $response_code for $url" >&2
            rm -f "$output_file"
            return 1
        fi
    done
    
    echo "Failed to download after $max_retries retries: $url" >&2
    return 1
}

#############################################
# Workspace
#############################################

WORKDIR=$(pwd)/migration-work
mkdir -p "$WORKDIR"
cd "$WORKDIR"

#############################################
# CSV Report
#############################################

REPORT="$WORKDIR/migration-report.csv"

echo "package,version,source_repo,target_repo,packaging,status" > "$REPORT"

#############################################
# Maven Settings
#############################################

generate_maven_settings() {
    local target_token=$1
    cat > "$SETTINGS_FILE" <<EOF
<settings>
  <servers>

    <server>
      <id>github-target</id>
      <username>${GH_USER}</username>
      <password>${target_token}</password>
    </server>

  </servers>
</settings>
EOF
}

append_report_row() {
    echo "$1" >> "$REPORT"
}

SETTINGS_FILE="$WORKDIR/settings.xml"

# Generate initial settings with first target token
generate_maven_settings "$(get_target_token)"

#############################################
# Packages
#############################################

if ! packages=$(gh_api_paginated_with_retry source "orgs/${SOURCE_ORG}/packages?package_type=maven" | jq -r '.[].name'); then
    echo "Failed to fetch package list"
    exit 1
fi

packages=$(echo "$packages" | tr -d '\r')

total_packages=$(echo "$packages" | sed '/^$/d' | wc -l | tr -d '[:space:]')
package_index=0

for PACKAGE_NAME in $packages
do
    PACKAGE_NAME=$(echo "$PACKAGE_NAME" | tr -d '\r')

    package_index=$((package_index + 1))

    echo
    echo "[Package ${package_index}/${total_packages}]"

    echo
    echo "==================================="
    echo "Package: $PACKAGE_NAME"
    echo "==================================="

    if ! versions_json=$(gh_api_paginated_with_retry source "orgs/${SOURCE_ORG}/packages/maven/${PACKAGE_NAME}/versions" | jq -s 'add'); then
        echo "Failed to fetch versions for $PACKAGE_NAME"
        continue
    fi

    # Select the latest N by id, then deploy oldest->newest so newest is published last.
    if [ "$MAX_VERSIONS_PER_PACKAGE" -gt 0 ]; then
        versions_json=$(echo "$versions_json" | jq --argjson max "$MAX_VERSIONS_PER_PACKAGE" 'sort_by(.id) | reverse | .[:$max] | reverse')
    else
        versions_json=$(echo "$versions_json" | jq 'sort_by(.id)')
    fi

    version_count=$(echo "$versions_json" | jq length)
    version_index=0

    for ((i=0;i<version_count;i++))
    do
        version_index=$((version_index + 1))

        VERSION=$(echo "$versions_json" | jq -r ".[$i].name" | tr -d '\r')

        PACKAGE_HTML_URL=$(echo "$versions_json" | jq -r ".[$i].package_html_url")

        SOURCE_REPO=$(echo "$PACKAGE_HTML_URL" | awk -F'/' '{print $5}')

        TARGET_REPO="$SOURCE_REPO"

        echo
        echo "[Version ${version_index}/${version_count}]"
        echo "Version      : $VERSION"
        echo "Source Repo  : $SOURCE_REPO"
        echo "Target Repo  : $TARGET_REPO"

        #########################################
        # Verify Target Repo
        #########################################

        if ! GH_TOKEN=$(get_target_token) gh api \
            "repos/${TARGET_ORG}/${TARGET_REPO}" >/dev/null 2>&1
        then
            echo "Target repo not found. Skipping."

            echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,,TARGET_REPO_NOT_FOUND" \
                >> "$REPORT"

            continue
        fi

        #########################################
        # Determine coordinates
        #########################################

        GROUP_ID="${PACKAGE_NAME%.*}"
        ARTIFACT_ID="${PACKAGE_NAME##*.}"

        GROUP_PATH=$(echo "$GROUP_ID" | tr '.' '/')

        BASE_URL="https://maven.pkg.${SOURCE_HOST}/${SOURCE_ORG}/${SOURCE_REPO}/${GROUP_PATH}/${ARTIFACT_ID}/${VERSION}"
        RESOLVED_VERSION="$VERSION"

        mkdir -p "${PACKAGE_NAME}-${VERSION}"
        cd "${PACKAGE_NAME}-${VERSION}"

        #########################################
        # Metadata
        #########################################

        if ! download_file_with_retry source \
            "https://maven.pkg.${SOURCE_HOST}/${SOURCE_ORG}/${SOURCE_REPO}/${GROUP_PATH}/${ARTIFACT_ID}/maven-metadata.xml" \
            metadata.xml; then
            echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,,DOWNLOAD_FAILED" \
                >> "$REPORT"

            cd ..
            continue
        fi

        #########################################
        # Resolve SNAPSHOT filename version
        #########################################

        if [[ "$VERSION" == *-SNAPSHOT ]]
        then
            if ! download_file_with_retry source \
                "${BASE_URL}/maven-metadata.xml" \
                version-metadata.xml; then
                echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,,DOWNLOAD_FAILED" \
                    >> "$REPORT"

                cd ..
                continue
            fi

            version_metadata_normalized=$(sed 's:><:>\n<:g' version-metadata.xml)

            snapshot_pom_value=$(echo "$version_metadata_normalized" | awk '
                /<snapshotVersion>/ { in_block=1; block="" }
                in_block { block=block $0 }
                /<\/snapshotVersion>/ {
                    if (block ~ /<extension>pom<\/extension>/ && block !~ /<classifier>/) {
                        if (match(block, /<value>[^<]+<\/value>/)) {
                            value = substr(block, RSTART + 7, RLENGTH - 15)
                            print value
                            exit
                        }
                    }
                    in_block=0
                }
            ')

            if [ -n "$snapshot_pom_value" ]
            then
                RESOLVED_VERSION="$snapshot_pom_value"
            else
                snapshot_timestamp=$(echo "$version_metadata_normalized" | awk -F'[<>]' '/<timestamp>/{print $3; exit}')
                snapshot_build_number=$(echo "$version_metadata_normalized" | awk -F'[<>]' '/<buildNumber>/{print $3; exit}')

                if [ -n "$snapshot_timestamp" ] && [ -n "$snapshot_build_number" ]
                then
                    RESOLVED_VERSION="${VERSION%-SNAPSHOT}-${snapshot_timestamp}-${snapshot_build_number}"
                fi
            fi
        fi

        #########################################
        # POM
        #########################################

        if ! download_file_with_retry source \
            "${BASE_URL}/${ARTIFACT_ID}-${RESOLVED_VERSION}.pom" \
            "${ARTIFACT_ID}-${VERSION}.pom"; then
            echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,,DOWNLOAD_FAILED" \
                >> "$REPORT"

            cd ..
            continue
        fi

        if ! grep -q "<project" "${ARTIFACT_ID}-${VERSION}.pom"
        then
            echo "Invalid POM"

            cd ..

            echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,,INVALID_POM" \
                >> "$REPORT"

            continue
        fi

        #########################################
        # Packaging
        #########################################

        PACKAGING=$(
            grep -oP '(?<=<packaging>)[^<]+' "${ARTIFACT_ID}-${VERSION}.pom" 2>/dev/null || true
        )

        if [ -z "$PACKAGING" ]
        then
            PACKAGING=jar
        fi

        echo "Packaging: $PACKAGING"

        #########################################
        # Download Artifact
        #########################################

        ARTIFACT_FILE="${ARTIFACT_ID}-${RESOLVED_VERSION}.${PACKAGING}"

        if ! download_file_with_retry source \
            "${BASE_URL}/${ARTIFACT_FILE}" \
            "${ARTIFACT_FILE}"; then
            echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,$PACKAGING,DOWNLOAD_FAILED" \
                >> "$REPORT"

            cd ..
            continue
        fi

        if [ ! -s "${ARTIFACT_FILE}" ]
        then

            cd ..

            echo "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,$PACKAGING,DOWNLOAD_FAILED" \
                >> "$REPORT"

            continue
        fi

        #########################################
        # Publish
        #########################################

        echo "Publishing..."

        STATUS="DEPLOY_FAILED"
        deploy_retries=0
        max_deploy_retries=3

        while [ $deploy_retries -lt $max_deploy_retries ]; do
            if mvn deploy:deploy-file \
                -s "$SETTINGS_FILE" \
                -DrepositoryId=github-target \
                -Durl=https://maven.pkg.${TARGET_HOST}/${TARGET_ORG}/${TARGET_REPO} \
                -DgroupId="${GROUP_ID}" \
                -DartifactId="${ARTIFACT_ID}" \
                -Dversion="${VERSION}" \
                -Dpackaging="${PACKAGING}" \
                -DpomFile="${ARTIFACT_ID}-${VERSION}.pom" \
                -Dfile="${ARTIFACT_FILE}" 2>&1 | tee deploy.log
            then
                STATUS="SUCCESS"
                break
            else
                if grep -qi "rate limit\|429\|too many requests" deploy.log; then
                    echo "Rate limit detected in deploy. Rotating token and retrying..." >&2
                    rotate_target_token
                    generate_maven_settings "$(get_target_token)"
                    deploy_retries=$((deploy_retries + 1))
                    sleep 2
                else
                    break
                fi
            fi
        done

        append_report_row "$PACKAGE_NAME,$VERSION,$SOURCE_REPO,$TARGET_REPO,$PACKAGING,$STATUS"

        cd ..

    done

done

echo
echo "===================================="
echo "Migration Completed"
echo "Report: ${REPORT}"
echo "===================================="