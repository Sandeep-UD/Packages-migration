# GitHub Packages Cleanup Script

This script fetches packages from a GitHub organization and deletes them by package type.

It can run in:
- Dry run mode (recommended first) to simulate deletions
- Real delete mode to actually remove packages

## What it does

1. Loads credentials and settings from `.env`
2. Fetches organization packages from the GitHub REST API (paginated)
3. Optionally deletes each package
4. Writes a CSV report: `deleted_packages.csv`
5. Writes errors to: `error.log`

## Requirements

- Python 3.8+
- A GitHub token with package deletion permissions for the target organization
- Python packages:
  - `requests`
  - `python-dotenv`

Install dependencies:

```powershell
pip install requests python-dotenv
```

## Configuration

Create/update `.env` in the same folder:

```env
GITHUB_TOKEN=your_github_token
ORG_NAME=your_org_name
PACKAGE_TYPE=maven
DRY_RUN=true
```

### Environment variables

- `GITHUB_TOKEN` (required)
  - GitHub Personal Access Token or GitHub App token with required package permissions.
- `ORG_NAME` (required)
  - GitHub organization name.
- `PACKAGE_TYPE` (optional, default: `maven`)
  - One of: `npm`, `maven`, `nuget`, `rubygems`, `container`, or `all`.
- `DRY_RUN` (optional, default in script: `true`)
  - `true` = no deletions, only report as `DRY_RUN`
  - `false` = perform actual deletions

## Usage

From this folder, run:

```powershell
python Delete-packages.py
```

## Recommended workflow

1. Set `DRY_RUN=true`
2. Run the script and review `deleted_packages.csv`
3. Confirm targets are correct
4. Set `DRY_RUN=false`
5. Run again to perform deletions

## Output files

- `deleted_packages.csv`
  - Columns: `package_name`, `package_id`, `package_type`, `status`
- `error.log`
  - API and runtime errors

## Notes

- The script handles GitHub API rate-limit pauses automatically.
- A 1 second delay is added between delete operations to reduce abuse-detection risk.
- If `PACKAGE_TYPE=all`, the script processes all supported package types.

## Troubleshooting

- `GITHUB_TOKEN is missing in .env`
  - Add a token value to `GITHUB_TOKEN`.
- `ORG_NAME is missing in .env`
  - Set the correct organization name.
- `Unsupported PACKAGE_TYPE`
  - Use one of: `npm`, `maven`, `nuget`, `rubygems`, `container`, or `all`.
- Deletions fail with permission errors
  - Verify the token has organization package delete permissions.
