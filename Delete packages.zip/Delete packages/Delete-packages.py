#!/usr/bin/env python3

import os
import csv
import time
import logging
import requests
from dotenv import load_dotenv

# =====================================================
# Load Environment Variables
# =====================================================

load_dotenv()

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
ORG_NAME = os.getenv("ORG_NAME")

PACKAGE_TYPE = os.getenv("PACKAGE_TYPE", "maven").lower()
DRY_RUN = os.getenv("DRY_RUN", "true").lower() == "true"

SUPPORTED_PACKAGE_TYPES = [
    "npm",
    "maven",
    "nuget",
    "rubygems",
    "container"
]

if not GITHUB_TOKEN:
    raise ValueError("GITHUB_TOKEN is missing in .env")

if not ORG_NAME:
    raise ValueError("ORG_NAME is missing in .env")

# =====================================================
# Logging
# =====================================================

logging.basicConfig(
    filename="error.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# =====================================================
# GitHub Session
# =====================================================

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28"
})

BASE_URL = "https://api.github.com"

# =====================================================
# Rate Limit Handler
# =====================================================

def handle_rate_limit(response):
    remaining = response.headers.get("X-RateLimit-Remaining")

    if remaining == "0":
        reset_time = int(response.headers.get("X-RateLimit-Reset", time.time()))
        sleep_time = max(reset_time - int(time.time()), 0) + 5

        print(
            f"[INFO] Rate limit reached. "
            f"Sleeping {sleep_time} seconds..."
        )

        time.sleep(sleep_time)

# =====================================================
# Fetch Packages By Type
# =====================================================

def get_packages_by_type(package_type):

    packages = []
    page = 1
    per_page = 100

    while True:

        url = (
            f"{BASE_URL}/orgs/{ORG_NAME}/packages"
            f"?package_type={package_type}"
            f"&per_page={per_page}"
            f"&page={page}"
        )

        try:

            response = session.get(url)

            handle_rate_limit(response)

            if response.status_code != 200:

                logging.error(
                    f"Failed fetching {package_type} packages "
                    f"(page {page}) - "
                    f"{response.status_code}: {response.text}"
                )

                break

            data = response.json()

            if not data:
                break

            packages.extend(data)

            print(
                f"[INFO] {package_type}: "
                f"Retrieved {len(data)} package(s) "
                f"from page {page}"
            )

            page += 1

        except Exception as e:

            logging.error(
                f"Error fetching {package_type} packages: {str(e)}"
            )

            break

    return packages

# =====================================================
# Delete Package
# =====================================================

def delete_package(package_name, package_type):

    try:

        if DRY_RUN:
            return True, "DRY_RUN"

        url = (
            f"{BASE_URL}/orgs/{ORG_NAME}/packages/"
            f"{package_type}/{package_name}"
        )

        response = session.delete(url)

        handle_rate_limit(response)

        if response.status_code in [202, 204]:
            return True, "DELETED"

        logging.error(
            f"Failed deleting {package_type}/{package_name} - "
            f"{response.status_code}: {response.text}"
        )

        return False, f"FAILED ({response.status_code})"

    except Exception as e:

        logging.error(
            f"Exception deleting {package_type}/{package_name}: {str(e)}"
        )

        return False, "ERROR"

# =====================================================
# Main
# =====================================================

def main():

    if PACKAGE_TYPE == "all":
        package_types = SUPPORTED_PACKAGE_TYPES
    else:

        if PACKAGE_TYPE not in SUPPORTED_PACKAGE_TYPES:
            raise ValueError(
                f"Unsupported PACKAGE_TYPE '{PACKAGE_TYPE}'. "
                f"Supported values: "
                f"{', '.join(SUPPORTED_PACKAGE_TYPES)} or all"
            )

        package_types = [PACKAGE_TYPE]

    all_packages = []

    print("\n====================================")
    print("GitHub Package Cleanup")
    print("====================================")
    print(f"Organization : {ORG_NAME}")
    print(f"Package Type : {PACKAGE_TYPE}")
    print(f"Dry Run      : {DRY_RUN}")
    print("====================================\n")

    # Fetch packages

    for package_type in package_types:

        print(
            f"[INFO] Fetching '{package_type}' packages..."
        )

        packages = get_packages_by_type(package_type)

        print(
            f"[INFO] Found {len(packages)} "
            f"{package_type} package(s)"
        )

        for package in packages:
            package["package_type"] = package_type

        all_packages.extend(packages)

    print(
        f"\n[INFO] Total Packages Found: "
        f"{len(all_packages)}\n"
    )

    # CSV Output

    output_file = "deleted_packages.csv"

    with open(
        output_file,
        mode="w",
        newline="",
        encoding="utf-8"
    ) as csvfile:

        writer = csv.writer(csvfile)

        writer.writerow([
            "package_name",
            "package_id",
            "package_type",
            "status"
        ])

        for index, package in enumerate(all_packages, start=1):

            package_name = package.get("name")
            package_id = package.get("id")
            package_type = package.get("package_type")

            print(
                f"[{index}/{len(all_packages)}] "
                f"{package_type}/{package_name}"
            )

            success, status = delete_package(
                package_name,
                package_type
            )

            writer.writerow([
                package_name,
                package_id,
                package_type,
                status
            ])

            print(f"    -> {status}")

            # Avoid abuse detection
            time.sleep(1)

    print("\n====================================")
    print("Completed")
    print("====================================")
    print(f"CSV Report : {output_file}")
    print("Error Log  : error.log")
    print("====================================")

# =====================================================
# Entry Point
# =====================================================

if __name__ == "__main__":
    main()